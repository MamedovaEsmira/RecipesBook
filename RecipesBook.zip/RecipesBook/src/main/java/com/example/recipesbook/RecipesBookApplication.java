package com.example.recipesbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipesBookApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecipesBookApplication.class, args);
    }

}
